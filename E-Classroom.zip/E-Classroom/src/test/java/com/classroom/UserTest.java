package com.classroom;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.classroom.model.User;
import com.classroom.service.UserService;
@SpringBootTest
class UserTest {
	@Autowired UserService userService;
	 static User user;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	    user=new User();
		user.setFirstName("Rajshri");
		user.setLastName("Mulegaon");
		user.setMobileNo("7447639651");
		user.setCountry("India");
		user.setState("Maharashtra");
		user.setCity("Solapur");
		user.seteMail("raj21@gmail.com");
		user.setEnabled(false);
		user.setRole("Student");
		user.setUsername("RajshriMulegaon");
		user.setPassword("Rajshri@21");		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}
	@Disabled
	@Test
	void testGetAllUsers() {
		assertNotNull(userService.getAllUsers());
	}
	@Disabled
	@Test
	void testGetAllStudents() {
		assertNotNull(userService.getAllStudents());
	}
	@Disabled
	@Test
	void testGetAllTeachers() {
		assertNotNull(userService.getAllTeachers());
	}
	@Disabled
	@Test
	void testGetUserById() {
		assertNotNull(userService.loginUser(user));
	}
	
	
	@Test
	void testfindByUsernameAndPassword() {
		assertNotNull(userService.getUserById(1));
	}
	@Disabled
	@Test
	void testDeleteUser() {
		assertNotNull(userService.deleteUser(1));
	}
	@Disabled
	@Test
	void test() {
		assertNotNull(userService.registerUser(user));
	}
	
}
